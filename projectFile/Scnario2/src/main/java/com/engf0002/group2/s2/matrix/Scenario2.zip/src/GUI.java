import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class GUI extends JFrame{
    private MatrixModel model;
    private JPanel topPanel;
    private JComboBox<String> menu;
    private JLabel selectLabel;
    private JLabel rowLabel;
    private JComboBox<Integer> rowSize;
    private JLabel columnLabel;
    private JComboBox<Integer> columnSize;
    private JButton confirm;
    private JLabel tip;
    private JFrame calculatorWindow;
    private JPanel matricesPanel;
    private DefaultTableModel resultModel = new DefaultTableModel();
    private Matrix resultMatrix;

    public GUI(){
        this.model = new MatrixModel();
        createGUI();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void createGUI(){
        setTitle("Matrix Calculator");
        createSelectLabel();
        createMenu();
        createSizeLabel();
        createConfirmButton();
        createTopPanel();
    }

    private void createSelectLabel(){
        selectLabel = new JLabel("Select a function:");
    }

    private void createMenu(){
        menu = new JComboBox<>();
        String[] functionNames = {"Add Matrices", "Subtract Matrices", "Multiply Matrices", "Find determinant", "Find Transpose"};
        for(String functionName : functionNames){
            menu.addItem(functionName);
        }
    }

    private void createSizeLabel(){
        rowLabel = new JLabel("Row Size:");
        rowSize = new JComboBox<>();
        for(int rowIndex = 1; rowIndex <= 5; rowIndex++){
            rowSize.addItem(rowIndex);
        }

        columnLabel = new JLabel("Column Size:");
        columnSize = new JComboBox<>();
        for(int columnIndex = 1; columnIndex <= 5; columnIndex++){
            columnSize.addItem(columnIndex);
        }
    }

    private void createConfirmButton(){
        confirm = new JButton("Confirm");
        confirm.addActionListener((ActionEvent e) -> displayMatrices());
    }

    private void displayMatrices(){
        if(menu.getSelectedItem().toString().equals("Find determinant")){
            if(Integer.parseInt(rowSize.getSelectedItem().toString()) != Integer.parseInt(columnSize.getSelectedItem().toString())){
                return;
            }
        }

        calculatorWindow = new JFrame();
        calculatorWindow.setTitle(menu.getSelectedItem().toString());
        calculatorWindow.setSize(500, 400);

        createTipLabel();
        calculatorWindow.add(tip, BorderLayout.NORTH);
        createMatricesPanel();
        calculatorWindow.add(matricesPanel, BorderLayout.CENTER);

        calculatorWindow.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        calculatorWindow.setLocationRelativeTo(null);
        calculatorWindow.setVisible(true);
    }

    private void createMatricesPanel(){
        String userSelect = menu.getSelectedItem().toString();
        int rowNumber = Integer.parseInt(rowSize.getSelectedItem().toString());
        int columnNumber = Integer.parseInt(columnSize.getSelectedItem().toString());

        resultModel = new DefaultTableModel();

        if(userSelect.equals("Add Matrices") || userSelect.equals("Subtract Matrices")){
            matricesPanel = new JPanel(new GridLayout(3, 2, 0, 0));

            Float[] columns = new Float[columnNumber];

            Float[][] matrix1Data = new Float[rowNumber][columnNumber];
            Float[][] matrix2Data = new Float[rowNumber][columnNumber];
            Float[][] resultData = new Float[rowNumber][columnNumber];

            Matrix matrix1 = new Matrix(rowNumber, columnNumber);
            Matrix matrix2 = new Matrix(rowNumber, columnNumber);
            ArrayList<ArrayList<Float>> matrix1Array = matrix1.getMatrix();
            ArrayList<ArrayList<Float>> matrix2Array = matrix2.getMatrix();

            for(int rowIndex = 0; rowIndex < rowNumber; rowIndex++){
                ArrayList<Float> row1 = matrix1Array.get(rowIndex);
                ArrayList<Float> row2 = matrix2Array.get(rowIndex);
                for(int columnIndex = 0; columnIndex < columnNumber; columnIndex++){
                    matrix1Data[rowIndex][columnIndex] = row1.get(columnIndex);
                    matrix2Data[rowIndex][columnIndex] = row2.get(columnIndex);
                }
            }


            DefaultTableModel matrixModel1 = new DefaultTableModel(matrix1Data, columns);
            JTable matrixTable1 = new JTable(matrixModel1);

            DefaultTableModel matrixModel2 = new DefaultTableModel(matrix2Data, columns);
            JTable matrixTable2 = new JTable(matrixModel2);

            resultModel = new DefaultTableModel(resultData, columns);

            matricesPanel.add(new JLabel("Matrix 1:"));
            matricesPanel.add(matrixTable1);
            matricesPanel.add(new JLabel("Matrix 2:"));
            matricesPanel.add(matrixTable2);

            if(userSelect.equals("Add Matrices")){
                matricesPanel.add(new JLabel("Add to:"));

                resultMatrix = this.model.addMatrices(matrix1, matrix2);
            }else{
                matricesPanel.add(new JLabel("Subtract to:"));

                resultMatrix = this.model.subtractMatrices(matrix1, matrix2);
            }

        }else if(userSelect.equals("Multiply Matrices")){
            matricesPanel = new JPanel(new GridLayout(3, 2, 0, 0));

            Float[] columns1 = new Float[columnNumber];
            Float[] columns2 = new Float[rowNumber];

            Float[][] matrix1Data = new Float[rowNumber][columnNumber];
            Float[][] matrix2Data = new Float[columnNumber][rowNumber];
            Float[][] resultData = new Float[rowNumber][rowNumber];

            Matrix matrix1 = new Matrix(rowNumber, columnNumber);
            Matrix matrix2 = new Matrix(columnNumber, rowNumber);
            ArrayList<ArrayList<Float>> matrix1Array = matrix1.getMatrix();
            ArrayList<ArrayList<Float>> matrix2Array = matrix2.getMatrix();

            for(int rowIndex = 0; rowIndex < rowNumber; rowIndex++){
                ArrayList<Float> row = matrix1Array.get(rowIndex);
                for(int columnIndex = 0; columnIndex < columnNumber; columnIndex++){
                    matrix1Data[rowIndex][columnIndex] = row.get(columnIndex);
                }
            }

            for(int rowIndex = 0; rowIndex < columnNumber; rowIndex++){
                ArrayList<Float> row = matrix2Array.get(rowIndex);
                for(int columnIndex = 0; columnIndex < rowNumber; columnIndex++){
                    matrix2Data[rowIndex][columnIndex] = row.get(columnIndex);
                }
            }



            DefaultTableModel matrixModel1 = new DefaultTableModel(matrix1Data, columns1);
            JTable matrixTable1 = new JTable(matrixModel1);

            DefaultTableModel matrixModel2 = new DefaultTableModel(matrix2Data, columns2);
            JTable matrixTable2 = new JTable(matrixModel2);

            resultModel = new DefaultTableModel(resultData, columns2);
            resultMatrix = this.model.multiplyMatrices(matrix1, matrix2);

            matricesPanel.add(new JLabel("Matrix 1:"));
            matricesPanel.add(matrixTable1);
            matricesPanel.add(new JLabel("Matrix 2:"));
            matricesPanel.add(matrixTable2);
            matricesPanel.add(new JLabel("Multiply to:"));

        }else if(userSelect.equals("Find determinant") || userSelect.equals("Find Transpose")){
            matricesPanel = new JPanel(new GridLayout(2, 2, 0, 0));

            Float[] columns1 = new Float[columnNumber];

            Float[][] matrixData = new Float[rowNumber][columnNumber];

            Matrix testMatrix = new Matrix(rowNumber, columnNumber);

            if(userSelect.equals("Find determinant")){
                while(true){
                    if(this.model.hasDeterminant(testMatrix)){
                        break;
                    }
                    testMatrix = new Matrix(rowNumber, columnNumber);
                }

                resultModel = new DefaultTableModel(new Float[1][1], new Float[1]);
                resultMatrix = this.model.findDeterminant(testMatrix);
            }else{
                resultModel = new DefaultTableModel(new Float[columnNumber][rowNumber], new Float[rowNumber]);
                resultMatrix = this.model.findTranspose(testMatrix);
            }

            ArrayList<ArrayList<Float>> matrix = testMatrix.getMatrix();

            for(int rowIndex = 0; rowIndex < rowNumber; rowIndex++){
                ArrayList<Float> row = matrix.get(rowIndex);
                for(int columnIndex = 0; columnIndex < columnNumber; columnIndex++){
                    matrixData[rowIndex][columnIndex] = row.get(columnIndex);
                }
            }


            DefaultTableModel matrixModel1 = new DefaultTableModel(matrixData, columns1);
            JTable matrixTable1 = new JTable(matrixModel1);

            matricesPanel.add(new JLabel("Matrix:"));
            matricesPanel.add(matrixTable1);

            if(userSelect.equals("Find determinant")){
                matricesPanel.add(new JLabel("Determinant:"));
            }else{
                matricesPanel.add(new JLabel("Transpose:"));
            }
        }

        matricesPanel.add(new JTable(resultModel));

        JButton checkButton = new JButton("Check");
        checkButton.addActionListener((ActionEvent e) -> checkAnswer());
        calculatorWindow.add(checkButton, BorderLayout.SOUTH);
    }

    private void checkAnswer(){
        int rowNumber = resultMatrix.getRowNumber();
        int columnNumber = resultMatrix.getColumnNumber();
        for(int rowIndex = 0; rowIndex < rowNumber; rowIndex++){
            ArrayList<Float> row = resultMatrix.getRow(rowIndex);
            for(int columnIndex = 0; columnIndex < columnNumber; columnIndex++){
                float result;
                if(resultModel.getValueAt(rowIndex, columnIndex) == null){
                    result = 0f;
                }else{
                    result = Float.parseFloat(resultModel.getValueAt(rowIndex, columnIndex).toString());
                }

                float answer = row.get(columnIndex);
                if(!((int) answer == (int) result)){
                    tip.setText("Wrong answer! You can try again!");
                    return;
                }

            }
        }

        tip.setText("Congratulation!");
    }

    private void createTipLabel(){
        tip = new JLabel();
        String userSelect = menu.getSelectedItem().toString();

        switch (userSelect) {
            case "Add Matrices" -> tip.setText("Tips : add numbers together at the same position. x11 + y11 = z11");
            case "Subtract Matrices" -> tip.setText("Tips : subtract numbers at the same position. x11 - y11 = z11");
            case "Multiply Matrices" -> tip.setText("Tips : multiply a row with a column. x11 = row1 * col1");
            case "Find determinant" -> tip.setText("Tips : find determinant by Gaussian Elimination.");
            case "Find Transpose" -> tip.setText("Tips : exchange every row with column. row1 = column1");
        }
    }

    private void createTopPanel(){
        topPanel = new JPanel(new GridLayout(3, 2, 5, 0));
        topPanel.setBorder(BorderFactory.createEtchedBorder());
        topPanel.add(selectLabel);
        topPanel.add(menu);
        topPanel.add(rowLabel);
        topPanel.add(rowSize);
        topPanel.add(columnLabel);
        topPanel.add(columnSize);
        add(topPanel, BorderLayout.CENTER);
        add(confirm, BorderLayout.SOUTH);
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(GUI::new);
    }
}