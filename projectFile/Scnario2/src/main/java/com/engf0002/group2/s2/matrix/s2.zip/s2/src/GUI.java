import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class GUI extends JFrame {
    private JTextField result_display_area;
    private JTextField regex_input_area;
    private JTextField string_input_area;
    private final int text_field_column = 20;
    private JPanel text_panel;
    private JPanel button_panel;
    private JLabel result_label = new JLabel("Result:");
    private JLabel regex_label = new JLabel("Regular Expression:");
    private JLabel input_label = new JLabel("Input:");
    private JButton match_button;
    private Model model = new Model();

    public GUI(){
        super("Regex Validator");
        initialisation();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initialisation(){
        create_text_panel();
        create_button_panel();
        this.add(text_panel,BorderLayout.CENTER);
        this.add(button_panel,BorderLayout.SOUTH);
    }

    private void create_button_panel(){
        create_match_button();
        button_panel = new JPanel();
        button_panel.setLayout(new BorderLayout());
        button_panel.add(match_button,BorderLayout.EAST);
    }

    private void create_text_panel(){
        create_regex_input_area();
        create_result_display_area();
        create_string_input_area();
        text_panel = new JPanel();
        text_panel.setLayout(new GridLayout(6,1));
        text_panel.add(regex_label);
        text_panel.add(regex_input_area);
        text_panel.add(input_label);
        text_panel.add(string_input_area);
        text_panel.add(result_label);
        text_panel.add(result_display_area);
    }

    private void create_result_display_area(){
        result_display_area = new JTextField(text_field_column);
        result_display_area.setEditable(false);
    }

    private void create_match_button(){
        match_button = new JButton("Match");
        match_button.addActionListener((ActionEvent e)->{
            String message = model.match(regex_input_area.getText(),string_input_area.getText());
            result_display_area.setText(message);
            refresh();
        });
    }

    private void create_regex_input_area(){
        regex_input_area = new JTextField(text_field_column);
    }

    private void create_string_input_area(){
        string_input_area = new JTextField(text_field_column);
    }

    private void refresh(){
        this.invalidate();
        this.validate();
        this.repaint();
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUI();
            }
        });
    }

}
